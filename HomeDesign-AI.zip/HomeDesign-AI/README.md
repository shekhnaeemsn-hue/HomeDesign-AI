# HomeDesign AI Android App

A polished Jetpack Compose Android implementation based on the supplied HomeDesign AI dashboard reference.

## Included
- Responsive dashboard-style UI
- Room type + interior style selectors
- Gallery image picker
- Budget slider
- AI generation state with a demo makeover result
- Saved designs list
- AI Assistant screen
- Settings screen
- Material 3 styling

## Build
Open this folder in Android Studio (Ladybug or newer), let Gradle sync, then run the `app` configuration on an Android 8.0+ device/emulator.

For an APK: **Build > Build APK(s)**.

## Real AI integration
The current app intentionally does **not** embed an API key. The `Generate Design` action is a safe local demo flow. To make it a real AI room-generation product, connect the action to your own backend that authenticates users and calls your chosen image-generation/vision provider. Never ship a secret API key directly inside the Android APK.

Suggested production flow:
1. Android uploads the selected room photo to your backend.
2. Backend validates the image and user request.
3. Backend calls the AI image/vision service.
4. Backend returns a generated image URL + recommendations.
5. Android displays the result and stores the design.

## Package
`com.homedesignai.app`
