# HomeDesign AI release rules
