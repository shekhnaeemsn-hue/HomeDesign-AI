package com.homedesignai.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

private val Cream = Color(0xFFF7F4EF)
private val Card = Color(0xFFFFFCF8)
private val Ink = Color(0xFF272523)
private val Muted = Color(0xFF77716B)
private val Line = Color(0xFFE7E0D8)
private val Accent = Color(0xFF3E3933)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { HomeDesignAIApp() } }
}

data class Design(val title: String, val style: String, val room: String, val date: String, val image: Uri? = null)

enum class NavItem(val label: String) { Dashboard("Dashboard"), Designs("My Designs"), Assistant("AI Assistant"), Saved("Saved Ideas"), Settings("Settings") }

@Composable fun HomeDesignAIApp() {
    var selected by remember { mutableStateOf(NavItem.Dashboard) }
    var designs by remember { mutableStateOf(listOf(
        Design("Living Room - Modern", "Modern", "Living Room", "Apr 12, 2025"),
        Design("Bedroom - Scandinavian", "Scandinavian", "Bedroom", "Apr 10, 2025"),
        Design("Kitchen - Minimalist", "Minimalist", "Kitchen", "Apr 8, 2025"),
        Design("Living Room - Luxury", "Luxury", "Living Room", "Apr 5, 2025")
    )) }
    MaterialTheme(colorScheme = lightColorScheme(background = Cream, surface = Card, onSurface = Ink, primary = Accent)) {
        Row(Modifier.fillMaxSize().background(Cream)) {
            Sidebar(selected) { selected = it }
            when (selected) {
                NavItem.Dashboard -> DashboardScreen(onSaved = { d -> designs = listOf(d) + designs })
                NavItem.Designs -> DesignsScreen(designs)
                NavItem.Assistant -> AssistantScreen()
                NavItem.Saved -> DesignsScreen(designs, title = "Saved Ideas")
                NavItem.Settings -> SettingsScreen()
            }
        }
    }
}

@Composable private fun Sidebar(selected: NavItem, onSelect: (NavItem)->Unit) {
    Column(Modifier.width(218.dp).fillMaxHeight().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Ink), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Home, null, tint=Color.White) }
                Spacer(Modifier.width(10.dp)); Column { Text("HomeDesign AI", fontSize=21.sp, fontWeight=FontWeight.Bold); Text("Design Your Dream Space", fontSize=9.sp, color=Muted) }
            }
            Spacer(Modifier.height(22.dp))
            NavItem.values().forEach { item ->
                val active = selected == item
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if(active) Color(0xFFE9E2D9) else Color.Transparent).clickable { onSelect(item) }.padding(horizontal=12.dp, vertical=12.dp), verticalAlignment=Alignment.CenterVertically) {
                    Icon(when(item){NavItem.Dashboard->Icons.Outlined.Home;NavItem.Designs->Icons.Outlined.FavoriteBorder;NavItem.Assistant->Icons.Outlined.AutoAwesome;NavItem.Saved->Icons.Outlined.BookmarkBorder;NavItem.Settings->Icons.Outlined.Settings}, null, tint=if(active) Ink else Muted, modifier=Modifier.size(19.dp))
                    Spacer(Modifier.width(12.dp)); Text(item.label, fontSize=13.sp, fontWeight=if(active) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
        Card(shape=RoundedCornerShape(12.dp), colors=CardDefaults.cardColors(containerColor=Color(0xFFEAE2D7))) {
            Column(Modifier.padding(12.dp)) { Text("Better Spaces\nHappier Lives", fontWeight=FontWeight.Bold, fontSize=14.sp); Spacer(Modifier.height(4.dp)); Text("Let AI design the perfect space for you.", fontSize=10.sp, color=Muted); Spacer(Modifier.height(10.dp)); Button(onClick={}, modifier=Modifier.fillMaxWidth(), contentPadding=PaddingValues(6.dp)) { Text("Upgrade to Pro", fontSize=11.sp) } }
        }
    }
}

@Composable private fun Header() {
    Row(Modifier.fillMaxWidth().padding(horizontal=22.dp, vertical=18.dp), verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text("☀  Good morning, Naeem", fontSize=19.sp, fontWeight=FontWeight.Bold); Text("Turn your ideas into beautiful spaces with HomeDesign AI", fontSize=10.sp, color=Muted) }
        OutlinedTextField(value="", onValueChange={}, placeholder={Text("Search designs, styles, furniture...", fontSize=11.sp)}, leadingIcon={Icon(Icons.Outlined.Search,null)}, modifier=Modifier.width(270.dp).height(45.dp), singleLine=true, shape=RoundedCornerShape(22.dp))
        Spacer(Modifier.width(14.dp)); Icon(Icons.Outlined.NotificationsNone, null, modifier=Modifier.size(22.dp)); Spacer(Modifier.width(14.dp)); Box(Modifier.size(34.dp).clip(CircleShape).background(Ink), contentAlignment=Alignment.Center){Text("N", color=Color.White, fontWeight=FontWeight.Bold)}; Spacer(Modifier.width(7.dp)); Text("Naeem⌄", fontSize=12.sp, fontWeight=FontWeight.SemiBold)
    }
}

@Composable private fun DashboardScreen(onSaved:(Design)->Unit) {
    var selectedRoom by remember { mutableStateOf("Living Room") }; var selectedStyle by remember { mutableStateOf("Modern") }; var budget by remember { mutableFloatStateOf(50f) }; var imageUri by remember { mutableStateOf<Uri?>(null) }; var generating by remember { mutableStateOf(false) }; var generated by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { imageUri = it }
    Column(Modifier.fillMaxSize()) { Header(); Row(Modifier.fillMaxSize().padding(horizontal=10.dp, vertical=2.dp), horizontalArrangement=Arrangement.spacedBy(12.dp)) {
        LeftControls(Modifier.width(286.dp), selectedRoom, {selectedRoom=it}, selectedStyle, {selectedStyle=it}, budget, {budget=it}, imageUri, {picker.launch("image/*")}) { generating=true }
        Column(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            PreviewCard(imageUri, generated, generating) { generated=false; imageUri=null }
            Recommendations(selectedStyle)
            Furniture()
        }
        RightRail()
    }}
    LaunchedEffect(generating){ if(generating){ delay(1500); generating=false; generated=true; onSaved(Design("$selectedRoom - $selectedStyle",selectedStyle,selectedRoom,"Today",imageUri)) } }
}

@Composable private fun LeftControls(modifier:Modifier, room:String, onRoom:(String)->Unit, style:String, onStyle:(String)->Unit, budget:Float, onBudget:(Float)->Unit, image:Uri?, onPick:()->Unit, onGenerate:()->Unit) {
    Card(modifier, shape=RoundedCornerShape(14.dp), border=BorderStroke(1.dp,Line)) { LazyColumn(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("Start Your Room Makeover", fontWeight=FontWeight.Bold, fontSize=15.sp); Text("Upload a photo or choose a room type to get AI-powered interior design suggestions.", fontSize=9.sp, color=Muted) }
        item { Box(Modifier.fillMaxWidth().height(100.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF9F6F1)).clickable{onPick()}, contentAlignment=Alignment.Center) { if(image!=null) AsyncImage(image, null, Modifier.fillMaxSize(), contentScale=ContentScale.Crop) else Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Outlined.CloudUpload,null); Text("Upload Room Image",fontWeight=FontWeight.SemiBold,fontSize=11.sp); Text("Tap to choose a photo",fontSize=9.sp,color=Muted)}} }
        item { Text("Choose Room Type", fontWeight=FontWeight.SemiBold, fontSize=11.sp); LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){items(listOf("Living Room","Bedroom","Kitchen","Bathroom","Dining Room","Office")){r-> ChoiceChip(r, room==r, {onRoom(r)})} } }
        item { Text("Interior Style", fontWeight=FontWeight.SemiBold, fontSize=11.sp); LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){items(listOf("Modern","Minimalist","Scandinavian","Luxury","Bohemian")){s-> StyleChip(s, style==s,{onStyle(s)})}} }
        item { Text("Colour Palette",fontWeight=FontWeight.SemiBold,fontSize=11.sp); Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){ listOf(0xFFDCCDB8,0xFFE8DFD3,0xFFB9B0A5,0xFF3E3B38,0xFF6B6258,0xFF927A61).forEach{Box(Modifier.size(21.dp).clip(CircleShape).background(Color(it)))}; Box(Modifier.size(21.dp).clip(CircleShape).background(Color.White),contentAlignment=Alignment.Center){Text("+",fontSize=12.sp)}} }
        item { Text("Budget Range",fontWeight=FontWeight.SemiBold,fontSize=11.sp); Slider(value=budget,onValueChange=onBudget); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("$5,000",fontSize=10.sp);Text("$${5000+(budget/100*10000).toInt()}",fontSize=10.sp,fontWeight=FontWeight.Bold)} }
        item { Button(onClick=onGenerate,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(24.dp)){Icon(Icons.Outlined.AutoAwesome,null);Spacer(Modifier.width(6.dp));Text("Generate Design") } }
    } }
}

@Composable private fun ChoiceChip(text:String, selected:Boolean, onClick:()->Unit){ Surface(onClick=onClick, shape=RoundedCornerShape(9.dp), color=if(selected) Color(0xFFE7DFD5) else Color.Transparent, border=BorderStroke(1.dp, if(selected) Ink else Line)){Text(text,Modifier.padding(horizontal=9.dp,vertical=8.dp),fontSize=9.sp,fontWeight=if(selected) FontWeight.Bold else FontWeight.Normal)} }
@Composable private fun StyleChip(text:String, selected:Boolean, onClick:()->Unit){ Column(Modifier.width(74.dp).clickable{onClick()}){Box(Modifier.height(52.dp).fillMaxWidth().clip(RoundedCornerShape(9.dp)).background(Brush.linearGradient(listOf(Color(0xFFE8DFD3),Color(0xFFB8A38B)))),contentAlignment=Alignment.Center){Text(text.take(1),fontSize=18.sp,fontWeight=FontWeight.Bold,color=Color.White)}Text(text,Modifier.padding(top=4.dp),fontSize=9.sp,fontWeight=if(selected) FontWeight.Bold else FontWeight.Normal)} }

@Composable private fun PreviewCard(image:Uri?,generated:Boolean,generating:Boolean,onReset:()->Unit){ Card(shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(14.dp)){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Room Makeover Preview",fontWeight=FontWeight.Bold,fontSize=15.sp);Text("Here’s your AI-powered transformation",fontSize=9.sp,color=Muted)}OutlinedButton(onClick={},contentPadding=PaddingValues(horizontal=12.dp,vertical=6.dp)){Icon(Icons.Outlined.Download,null,Modifier.size(15.dp));Spacer(Modifier.width(5.dp));Text("Download",fontSize=10.sp)};Spacer(Modifier.width(7.dp));IconButton(onClick=onReset){Icon(Icons.Outlined.MoreHoriz,null)}};Spacer(Modifier.height(10.dp));Box(Modifier.fillMaxWidth().height(265.dp).clip(RoundedCornerShape(9.dp)).background(Color(0xFFD7D0C8))){if(image!=null) AsyncImage(image,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop); if(generated){Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Transparent,Color(0x556B6258)))),contentAlignment=Alignment.Center){Text("AI makeover ready ✨",color=Color.White,fontWeight=FontWeight.Bold,fontSize=18.sp)}};if(generating){Box(Modifier.fillMaxSize().background(Color(0x88000000)),contentAlignment=Alignment.Center){CircularProgressIndicator(color=Color.White);Spacer(Modifier.height(10.dp));Text("Designing your room…",color=Color.White)}};Row(Modifier.fillMaxWidth().padding(10.dp),horizontalArrangement=Arrangement.SpaceBetween){Badge("Before");Badge(if(generated)"After" else "Preview")}}}}
@Composable private fun Badge(t:String){Surface(color=Color(0xFFF9F5EF),shape=RoundedCornerShape(18.dp)){Text(t,Modifier.padding(horizontal=10.dp,vertical=6.dp),fontSize=10.sp,fontWeight=FontWeight.Bold)} }

@Composable private fun Recommendations(style:String){Card(shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(14.dp)){Text("AI Design Recommendations",fontWeight=FontWeight.Bold,fontSize=15.sp);Text("Based on your room, style and preferences",fontSize=9.sp,color=Muted);Spacer(Modifier.height(9.dp));LazyRow(horizontalArrangement=Arrangement.spacedBy(9.dp)){items(listOf("Modern & Cozy Style","Warm Neutral Colour Palette","Space Saving Furniture","Natural Light Enhancement")){r->Surface(shape=RoundedCornerShape(10.dp),color=Color(0xFFF8F4EF)){Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Outlined.AutoAwesome,null,Modifier.size(18.dp));Spacer(Modifier.width(7.dp));Text(r,fontSize=9.sp,fontWeight=FontWeight.SemiBold)}}}}}}}
@Composable private fun Furniture(){Card(shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(14.dp)){Text("Recommended Furniture & Decor",fontWeight=FontWeight.Bold,fontSize=15.sp);Text("Handpicked items for your design",fontSize=9.sp,color=Muted);Spacer(Modifier.height(8.dp));LazyRow(horizontalArrangement=Arrangement.spacedBy(10.dp)){items(listOf("Sofa - Modern Fabric Sofa" to "$899","Coffee Table - Oak Wood" to "$249","Area Rug - Neutral Beige" to "$199","Floor Lamp - Wooden Stand" to "$129")){(name,price)->Card(Modifier.width(155.dp),border=BorderStroke(1.dp,Line),shape=RoundedCornerShape(10.dp)){Column{Box(Modifier.fillMaxWidth().height(82.dp).background(Brush.verticalGradient(listOf(Color(0xFFE6DED2),Color(0xFFC8BBAA)))),contentAlignment=Alignment.Center){Icon(Icons.Outlined.Chair,null,Modifier.size(38.dp),tint=Color(0xFF6B6258))};Column(Modifier.padding(8.dp)){Text(name,fontSize=9.sp,fontWeight=FontWeight.SemiBold,maxLines=2,overflow=TextOverflow.Ellipsis);Text(price,fontSize=11.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(5.dp));OutlinedButton(onClick={},modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(2.dp)){Text("View item →",fontSize=8.sp)}}}}}}}}}

@Composable private fun RightRail(){Column(Modifier.width(285.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Card(shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(13.dp)){Text("Design Variations",fontWeight=FontWeight.Bold,fontSize=15.sp);Text("Explore different looks for your space",fontSize=9.sp,color=Muted);Spacer(Modifier.height(9.dp));LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){items(listOf("Modern","Scandinavian","Luxury","Bohemian")){s->Column(Modifier.width(58.dp)){Box(Modifier.height(66.dp).fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Brush.verticalGradient(listOf(Color(0xFFD8C9B8),Color(0xFF8D7C6B)))));Text(s,fontSize=8.sp,fontWeight=FontWeight.SemiBold);if(s=="Modern")Text("(Recommended)",fontSize=7.sp,color=Muted)}}}}}}
        DesignsMini(); CostCard(); SaveBar()
    }
}
@Composable private fun DesignsMini(){Card(shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(13.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Your Saved Designs",fontWeight=FontWeight.Bold,fontSize=14.sp);Text("View all →",fontSize=9.sp,color=Muted)}Spacer(Modifier.height(8.dp));LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){items(listOf("Living Room - Modern","Bedroom - Scandinavian","Kitchen - Minimalist","Living Room - Luxury")){d->Column(Modifier.width(122.dp)){Box(Modifier.height(72.dp).fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Brush.verticalGradient(listOf(Color(0xFFD7CCBE),Color(0xFF9C8E7D)))));Text(d,fontSize=8.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis);Text("Apr 12, 2025",fontSize=7.sp,color=Muted)}}}}}}
@Composable private fun CostCard(){Card(shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(13.dp)){Text("Estimated Renovation Cost",fontWeight=FontWeight.Bold,fontSize=14.sp);Text("Based on selected items and room size",fontSize=8.sp,color=Muted);Spacer(Modifier.height(7.dp));Text("$8,500 – $12,000",fontSize=20.sp,fontWeight=FontWeight.Bold);Text("Within your budget",fontSize=8.sp,fontWeight=FontWeight.SemiBold);Spacer(Modifier.height(7.dp));listOf("Furniture" to "$4,200","Decor & Lighting" to "$2,100","Paint & Finishes" to "$1,500","Labour (optional)" to "$700").forEach{(a,b)->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(a,fontSize=8.sp,color=Muted);Text(b,fontSize=8.sp,fontWeight=FontWeight.SemiBold)}}}}
@Composable private fun SaveBar(){Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF1E8)),shape=RoundedCornerShape(14.dp)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Outlined.CheckCircle,null,tint=Color(0xFF3B6B3B));Spacer(Modifier.width(7.dp));Text("Your dream space is just a click away!",Modifier.weight(1f),fontSize=8.sp,fontWeight=FontWeight.SemiBold);Button(onClick={},contentPadding=PaddingValues(horizontal=10.dp,vertical=5.dp)){Text("Save Design",fontSize=9.sp)}}}}

@Composable private fun DesignsScreen(designs:List<Design>, title:String="My Designs"){Column(Modifier.fillMaxSize()){Header();Column(Modifier.padding(22.dp)){Text(title,fontSize=24.sp,fontWeight=FontWeight.Bold);Text("Your AI interior design collection",fontSize=11.sp,color=Muted);Spacer(Modifier.height(18.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(designs){d->Card(border=BorderStroke(1.dp,Line),shape=RoundedCornerShape(14.dp)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(120.dp,80.dp).clip(RoundedCornerShape(9.dp)).background(Brush.verticalGradient(listOf(Color(0xFFE0D4C5),Color(0xFF9D8B78)))));Spacer(Modifier.width(12.dp));Column{Text(d.title,fontWeight=FontWeight.Bold);Text("${d.room} • ${d.style}",fontSize=10.sp,color=Muted);Text(d.date,fontSize=9.sp,color=Muted)}}}}}}}}}
@Composable private fun AssistantScreen(){Column(Modifier.fillMaxSize()){Header();Column(Modifier.padding(28.dp).widthIn(max=700.dp)){Text("AI Interior Assistant",fontSize=25.sp,fontWeight=FontWeight.Bold);Text("Ask HomeDesign AI for ideas, layouts, colours or furniture suggestions.",color=Muted,fontSize=12.sp);Spacer(Modifier.height(20.dp));Card(shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(18.dp)){Text("Try asking",fontWeight=FontWeight.Bold);listOf("How can I make my small living room look bigger?","Suggest a warm modern palette.","What furniture should I buy on a $5,000 budget?").forEach{Text("• $it",Modifier.padding(top=10.dp),fontSize=12.sp)}}};Spacer(Modifier.height(20.dp));OutlinedTextField("",{},placeholder={Text("Ask anything about your room...")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp));Button(onClick={}){Icon(Icons.Outlined.Send,null);Spacer(Modifier.width(6.dp));Text("Ask HomeDesign AI")}}}}
@Composable private fun SettingsScreen(){Column(Modifier.fillMaxSize()){Header();Column(Modifier.padding(28.dp)){Text("Settings",fontSize=25.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(15.dp));listOf("Profile","Notifications","AI preferences","Privacy & security","About HomeDesign AI").forEach{Card(Modifier.fillMaxWidth().padding(vertical=4.dp),shape=RoundedCornerShape(12.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text(it,Modifier.weight(1f),fontWeight=FontWeight.SemiBold);Icon(Icons.Outlined.ChevronRight,null)}}}}}}
